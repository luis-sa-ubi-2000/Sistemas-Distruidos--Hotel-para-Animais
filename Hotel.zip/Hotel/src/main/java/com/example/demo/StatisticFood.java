package com.example.demo;

public class StatisticFood {
    private String typeFood;
    private Long petCount;

    public String getTypeFood() {
        return typeFood;
    }

    public void setTypeFood(String typeFood) {
        this.typeFood = typeFood;
    }

    public Long getPetCount() {
        return petCount;
    }

    public void setPetCount(Long petCount) {
        this.petCount = petCount;
    }
}

